<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PW2</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/exemplo.css">
    <style>
        h2 {
            color: #ff0000;
        }
    </style>
</head>

<body>
    <h1>
        Variaveis e constantes PHP
    </h1>
    <?php
        //Variaveis

        $b = 773; //int
        $a = 4.0; //floater
        $c = ""; //string
        $e = ''; //stirng
        $d = null; //nulo
        $teste = false; //bool 

        //constante

        define(constant_name: "minha_const", value: "teste");
        const TESTE = "valor";
        print "o valor de teste é " . TESTE;


        //escrevendo na tela

        echo "<p>O valor de \$a é " . $a . "</p>\n";
        echo "\t<p>O valor de b é $b</p>\n";
        echo '\t<p>O valor de b é ' . $a . '</p>\n';
        print "\t<p>O valor de a + b é (773 + 4) = " . ($a + $b) . "</p>\n";

        echo "O valor de", TESTE;

        //Objeto DateTime

        $d = new DateTime("now",
         new DateTImeZOne("America/Sao_Paulo"));
        echo "\t<p>A data e hora atual é {$d->format("d/m/Y - H:i:s")}</p>\n";

    ?>

    <h1>Estruturas de decisão</h1>
    <h2>IF</h2>

    <?php 
    
        if ($a > $b) {
            echo "\t<p>Deu verdadeiro<\p>";
        }
        else if($a == $c && $b < $c){
            echo "\t<p>A é igual a C</p>";
        }
    
    ?>

    <h2>Switch</h2>
    <?php
        $a = 1;
        echo "";

        switch ($a) {
            case 1:
                echo "\t<p>O valor é 1!<p>\n";
                break;
            case 2:
                echo "\t<p>O valor é 2!<p>\n";
                break;
            case 3:
                echo "\t<p>O valor é 3!<p>\n";
                break;
            case 4:
                echo "\t<p>O valor é 4!<p>\n";
                break; 
            case 5:
            case 6:
            case 7:
            case 8:
                echo "\t<p>O valor é esta entre 5 e 8!<p>\n";
                break;       
            default:
                echo "\t<p>O valor não esta entre 1 e 8!<p>\n";
                break;    
        }
    
    ?>

    <h1>Estruturas de repetição</h1>
    <h2>Do... While</h2>

    <?php
    
        $i = 0;
        do {
            echo "\t<p>O valor de \$i é $i</p>\n";
            $i++;
        }while ($i <= 10);

    ?>

    <h2>While</h2>
    <?php
    
        $i = 0;
        while ($i <= 10) {
            echo "\t<p>O valor de \$i é $i</p>\n";
            $i++;
        }

    ?>

    <h2>For</h2>
    <?php
    
        for ($i = 0; $i <= 10; $i++) {
            echo "\t<p>O valor de \$i é $i</p>\n";
        }

    ?>

    <h2>Foreach</h2>
    <?php

        $vet = ["Zeca", "Pedreiro", "15 99999-9999"];

        foreach ($vet as $value) {
            echo "\t<p>O valor de \$i é $i</p>\n";
        }

        
    ?>

<script src="js/bootstrap.bundle.min.js"></script>

</body>

</html>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PW2</title>
    <link rel="stylesheet" href="css/exemplo.css">
</head>

<body>
    <h1>
        Variaveis e constantes PHP
    </h1>
    <?php
        //Variaveis

        $b = 773; //int
        $a = 4.0; //floater
        $c = ""; //string
        $e = ''; //stirng
        $d = null; //nulo
        $teste = false; //bool 

        //constante

        define(constant_name: "minha_const", value: "teste");
        const TESTE = "valor";
        print "o valor de teste é " . TESTE;


        //escrevendo na tela

        echo "<p>O valor de \$a é " . $a . "</p>\n";
        echo "\t<p>O valor de b é $b</p>\n";
        echo '\t<p>O valor de b é ' . $a . '</p>\n';
        print "\t<p>O valor de a + b é (773 + 4) = " . ($a + $b) . "</p>\n";

        echo "O valor de", TESTE;

        //Objeto DateTime

        $d = new DateTime("now",
         new DateTImeZOne("America/Sao_Paulo"));
        echo "\t<p>A data e hora atual é {$d->format("d/m/Y - H:i:s")}</p>\n";

    ?>

    <h1>Estruturas de decisão</h1>
    <h2>IF</h2>

    <?php 
    
        if ($a > $b) {
            echo "\t<p>Deu verdadeiro<\p>";
        }
        else if($a == $c && $b < $c){
            echo "\t<p>A é igual a C</p>";
        }
    
    ?>

    <h2>Switch</h2>
    <?php 
        switch($a ) {
            case "":
                break;
            
            default:
        }
    
    
    ?>

</body>

</html>
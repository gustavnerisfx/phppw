<!DOCTYPE html>
<html lang="pt-br"> 

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/exemplo.css">
    <style>
        h2 {
            color: #FF0000;
        }
    </style>
</head>

<body>
    <h1>Variáveis e constantes PHP</h1>
    <?php
        // Variável
        /*

        */
        $a = 2; // int
        $b = 0.0; //float
        $c = ""; //string
        $d = ''; //string
        $e = null; //nulo
        $teste = false; //bool

        //Constante
        define("MINHA_CONST", "teste");
        const TESTE = "valor";

        //Escrevendo na tela
        echo "<p>O valor de \$a é " . $a . "</p>\n";
        echo "\t<p>O valor de b é $b</p>\n";
        echo '\t<p>O valor de b é '.$b.'</p>\n';
        print "\t<p>O valor de a + b é " . $a + $b . "</p>\n";

        echo "O valor de " . TESTE;

        //Objeto DateTime
        $d = new DateTime("now",
         new DateTimeZone("America/Sao_Paulo"));
        echo "\t<p>A data e hora atual é {$d->format("d/m/Y - H:i:s")}</p>\n";

    ?>
    <h1>Estruturas de decisão</h1>
    <h2>IF</h2>
    <?php
        if ($a > $b) {
            echo "\t<p>Deu verdadeiro</p>";
        } else if ($a == $c && $b < $c) {
            echo "\t<p>A é igual a C</p>";
        }

    ?>
    <h2>SWITCH</h2>
    <?php
        $a = 5;
        echo "";
        switch ($a) {
            case 1:
                echo "\t<p>O valor é 1!</p>\n";
                break;
            case 2:
                echo "\t<p>O valor é 2!</p>\n";
                break;
            case 3:
                echo "\t<p>O valor é 3!</p>\n";
                break;
            case 4:
                echo "\t<p>O valor é 4!</p>\n";
                break;
            case 5:
            case 6:
            case 7:
            case 8:
                echo "\t<p>O valor está entre 5 e 8!</p>\n";
                echo "\t<p>Confira o valor!</p>\n";
                break;
            default:
                echo "\t<p>O valor não está entre 1 e 8!</p>\n";
                break;
        }
    ?>
    <h1>Estruturas de repetição</h1>
    <h2>Do..While</h2>
    <?php
        $i = 0;
        do {
            echo "\t<p>O valor de \$i é $i</p>\n";
            $i++;

            //if ($i == 6){
            //    break;
                // continue;
            //}
        } while ($i <= 10);
    ?>
    <h2>While</h2>
    <?php
        $i = 0;
        while ($i <= 10) {
            echo "\t<p>O valor de \$i é $i</p>\n";
            $i++;
        }
    ?>
    <h2>For</h2>
    <?php
        
        // while ($i <= 10) {
        //     echo "\t<p>O valor de \$i é $i</p>\n";
        //     $i++;
        // }
        for ($i = 0; $i <= 10; $i++) { 
            echo "\t<p>O valor de \$i é $i</p>\n";
        }

    ?>
    <h2>Foreach</h2>
    <?php
        $vet = ["Zeca", "Pedreiro", "15997233477"];
        $vet2 = array("Zeca", "Pedreiro", "15997233477", 123);
        $vet2[] = "Itu";
        array_push($vet2, "SP", "11 99999-9999");
        foreach ($vet as $value) {
            echo "\t<p>O valor atual é $value</p>\n";
        }
    ?>
    
    <h2>For com vetor indexado</h2>
    <?php
        for ($i = 0; $i < count($vet2); $i++) { 
            echo "\t<p>O valor da " . $i + 1 . 
            "ª posição do vetor \$vet2 é {$vet2[$i]}</p>\n";
        }
    ?>

    <h2>Foreach com vetor associativo</h2>
    <?php
        $vet_assoc = ["id"=>"1","nome"=>"Tião","telefone"=>"15997233488"];
        foreach ($vet_assoc as $key => $value) {
            echo "\t<p>O valor de $key do vetor \$vet_assoc é $value</p>\n";
        }
        echo "\t<p>Valor avulso de \$vet_assoc é {$vet_assoc["nome"]}</p>\n";
    ?>

    <h2>Foreach com vetor bidimencional</h2>
    <?php
        $vet_assoc = ["id"=>"1","nome"=>"Tião","telefone"=>"15997233488"];
        foreach ($vet_assoc as $key => $value) {
            echo "\t<p>O valor de $key do vetor \$vet_assoc é $value</p>\n";
        }
        echo "\t<p>Valor avulso de \$vet_assoc é {$vet_assoc["nome"]}</p>\n";
    ?>

    

    <?php

        $cars = array (
            ["Volvo", 22, 18],
            ["BMW", 15, 13],
            ["Saab", 5, 2],
            ["Land Rover", 17, 15],
            67
        );

        echo "\t<p>Valor avulso de \$cars é {$cars["1"]["1"]}</p>\n";

        for ($i=0; $i < count($cars); $i++) { 
            if(is_array( $cars[$i])) {
                for ($j=0; $j < count($cars[$i]); $j++ ) {
                    echo "\t<p>O valor da posição $j do vetor \$cars na posição $j é {$cars[$i][$j]}</p>\n";
                }
            } else {
                echo "\t<p>O valor da posição $i do vetor \$cars é {$cars[$i]}</p>\n";
            }
        }
        

    ?>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>